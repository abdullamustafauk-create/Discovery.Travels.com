/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface BusinessInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
  tagline: string;
}

export const BUSINESS_DATA: BusinessInfo = {
  name: "Discovery Travels",
  address: "Othman Bin Affan St, Doha, Qatar",
  phone: "+974 4427 2870",
  email: "info@discover.qa",
  tagline: "Your one-stop shop for comprehensive travel arrangements in Qatar.",
};

export const SERVICES: Service[] = [
  {
    id: "accommodation",
    title: "Global Accommodation",
    description: "Access to over 250,000 hotels, furnished apartments, and student accommodations in more than 10,000 destinations worldwide.",
    iconName: "Hotel",
  },
  {
    id: "transportation",
    title: "Transportation & Transfers",
    description: "Over 5,000 transfer options across 900 airports and city locations, plus car rentals and European train bookings.",
    iconName: "Car",
  },
  {
    id: "flights",
    title: "Flight Bookings",
    description: "Airline ticket reservations and flight bookings with competitive rates across global networks.",
    iconName: "Plane",
  },
  {
    id: "specialized",
    title: "Specialized Packages",
    description: "Tailored Disney specials, luxury cruise bookings, and personalized sightseeing tours.",
    iconName: "Compass",
  },
  {
    id: "essentials",
    title: "Travel Essentials",
    description: "Visa assistance, travel insurance, international driving licenses, and more.",
    iconName: "ShieldCheck",
  },
  {
    id: "concierge",
    title: "Personalized Concierge",
    description: "Managing every detail of your journey in one place with high-quality service.",
    iconName: "UserCheck",
  },
];
