import { motion } from 'motion/react';
import * as Icons from 'lucide-react';
import { SERVICES } from '../../types';
import { SectionTitle } from '../ui/Shared';

export default function ServicesGrid() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle subtitle="Our Range of Products">
          Comprehensive Travel Solutions
        </SectionTitle>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => {
            // @ts-ignore
            const Icon = Icons[service.iconName] || Icons.Plane;
            
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group p-8 rounded-3xl border border-slate-100 hover:border-accent/30 hover:bg-slate-50 transition-all duration-500"
              >
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-brand-900 mb-6 group-hover:bg-brand-900 group-hover:text-accent transition-colors shadow-sm">
                  <Icon size={32} strokeWidth={1.5} />
                </div>
                <h3 className="text-xl font-bold text-brand-900 mb-4 group-hover:text-brand-800">
                  {service.title}
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Global Statistics */}
        <div className="mt-20 p-12 bg-brand-900 rounded-[3rem] text-center text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl -mr-32 -mt-32" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -ml-32 -mb-32" />
          
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-4 gap-8 divide-y md:divide-y-0 md:divide-x divide-white/10">
            <div className="py-4 md:py-0">
              <div className="text-4xl font-serif text-accent mb-1 font-bold">250K+</div>
              <div className="text-sm text-slate-400 uppercase tracking-widest font-medium">Hotels Worldwide</div>
            </div>
            <div className="py-4 md:py-0">
              <div className="text-4xl font-serif text-accent mb-1 font-bold">10K+</div>
              <div className="text-sm text-slate-400 uppercase tracking-widest font-medium">Destinations</div>
            </div>
            <div className="py-4 md:py-0">
              <div className="text-4xl font-serif text-accent mb-1 font-bold">5K+</div>
              <div className="text-sm text-slate-400 uppercase tracking-widest font-medium">Transfer Options</div>
            </div>
            <div className="py-4 md:py-0">
              <div className="text-4xl font-serif text-accent mb-1 font-bold">900+</div>
              <div className="text-sm text-slate-400 uppercase tracking-widest font-medium">Airports Covered</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
