import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles, X, ChevronDown } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { BUSINESS_DATA, SERVICES } from '../../types';

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'ai' | 'user'; content: string }[]>([
    { role: 'ai', content: "Hello! I'm your Discovery Travel Assistant. How can I help you plan your next journey from Doha today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;
      setShowScrollButton(!isAtBottom);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });
      const systemPrompt = `
        You are the Discovery Travels AI Assistant. 
        Business Info: ${JSON.stringify(BUSINESS_DATA)}
        Available Services: ${JSON.stringify(SERVICES)}
        
        Your tone: Professional, luxury-oriented, helpful, and "Doha-centric".
        Capabilities: You help users plan trips, explain services (visa assistance, hotels, car rentals), and answer questions about travel from/to Qatar.
        
        FORMATTING RULES:
        - Use Markdown for all responses.
        - Use **bold** for emphasis.
        - Use bullet points for lists.
        - When presenting booking options or summaries, use tables (| Option | Details |) if relevant.
        - Keep responses concise but comprehensive.
        - Highlight contact details where appropriate.
        
        If asked for something outside travel, politely redirect them.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          { role: 'user', parts: [{ text: systemPrompt + "\n\nUser Question: " + userMsg }] }
        ],
      });

      setMessages(prev => [...prev, { role: 'ai', content: response.text || "I'm sorry, I couldn't process that request at the moment. Please call us directly at +974 4427 2870." }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'ai', content: "Our AI is currently resting. Please reach out to our concierge team at info@discover.qa for assistance." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Trigger Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        id="ai-assistant-trigger"
        className="fixed bottom-6 right-6 z-50 bg-brand-900 text-accent p-4 rounded-full shadow-2xl flex items-center gap-2 group"
      >
        <Sparkles size={24} className="group-hover:animate-pulse" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 font-bold text-sm uppercase tracking-widest whitespace-nowrap">
          Concierge AI
        </span>
      </motion.button>

      {/* Chat Windows */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            id="ai-chat-window"
            className="fixed bottom-24 right-6 z-50 w-[90vw] md:w-[500px] bg-white rounded-[2rem] shadow-2xl border border-slate-100 flex flex-col overflow-hidden max-h-[80vh]"
          >
            {/* Header */}
            <div className="bg-brand-900 p-6 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="bg-accent text-brand-900 p-2 rounded-xl">
                  <Bot size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-sm uppercase tracking-widest">Discovery AI</h3>
                  <p className="text-[10px] text-slate-400 font-medium">Concierge Service • Always Available</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)} 
                className="hover:text-accent transition-colors p-2 hover:bg-white/10 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="relative flex-1 bg-slate-50 overflow-hidden flex flex-col">
              <div 
                ref={scrollRef}
                onScroll={handleScroll}
                className="flex-1 p-6 overflow-y-auto space-y-4 scroll-smooth"
              >
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl text-sm prose prose-slate prose-sm ${
                      m.role === 'user' 
                        ? 'bg-brand-900 text-white rounded-tr-none' 
                        : 'bg-white text-slate-700 shadow-sm border border-slate-100 rounded-tl-none'
                    }`}>
                      {m.role === 'user' ? (
                        m.content
                      ) : (
                        <div className="markdown-body">
                          <ReactMarkdown remarkPlugins={[remarkGfm]}>
                            {m.content}
                          </ReactMarkdown>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm flex gap-1">
                      <div className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-accent rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                )}
              </div>

              {/* Scroll to Bottom Button */}
              {showScrollButton && (
                <button
                  onClick={scrollToBottom}
                  className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-accent text-brand-900 p-2 rounded-full shadow-lg hover:scale-110 transition-transform z-10"
                >
                  <ChevronDown size={20} />
                </button>
              )}
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-slate-100 shrink-0">
              <div className="flex gap-2 p-2 bg-slate-50 rounded-2xl border border-slate-100 focus-within:border-accent focus-within:bg-white transition-all">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Tell us your travel plans..."
                  className="flex-1 bg-transparent px-3 text-sm outline-none text-slate-700"
                />
                <button 
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="bg-brand-900 text-white p-3 rounded-xl hover:bg-brand-800 disabled:opacity-50 transition-all flex items-center justify-center"
                >
                  <Send size={18} />
                </button>
              </div>
              <p className="text-[9px] text-center text-slate-400 mt-2">
                Discovery AI can make mistakes. Check important travel info.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
