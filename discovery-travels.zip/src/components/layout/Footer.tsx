import { Phone, Mail, MapPin, Instagram, Facebook, Youtube } from 'lucide-react';
import { BUSINESS_DATA } from '../../types';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-brand-900 pt-20 pb-10 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Col */}
          <div className="lg:col-span-1">
            <div className="flex flex-col mb-6">
              <span className="text-2xl font-bold tracking-tight text-white">Discovery</span>
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-accent">Travels</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-8">
              Excellence in travel arrangements since day one. Based in the heart of Doha, we connect you to the finest destinations worldwide.
            </p>
        <div className="flex gap-4">
          {[
            { Icon: Instagram, href: 'https://www.instagram.com/discovery.travels.qa/' },
            { Icon: Facebook, href: 'https://www.facebook.com/DiscoveryTravelsQatar/' },
            { Icon: Youtube, href: 'https://www.youtube.com/@discoverytravels-qatar4118' }
          ].map(({ Icon, href }, i) => (
            <a 
              key={i} 
              href={href} 
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-accent hover:border-accent hover:text-brand-900 transition-all"
            >
              <Icon size={18} />
            </a>
          ))}
        </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Quick Links</h3>
            <ul className="space-y-4">
              {[
                { name: 'Home', href: '#' },
                { name: 'Services', href: '#services' },
                { name: 'About Us', href: '#about' },
                { name: 'Contact', href: '#contact-form' },
                { name: 'Terms of Service', href: '#' },
                { name: 'Privacy Policy', href: '#' }
              ].map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-slate-400 hover:text-accent transition-colors text-sm">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">Our Services</h3>
            <ul className="space-y-4">
              {[
                'Hotel Bookings', 
                'Flight Reservations', 
                'Airport Transfers', 
                'Visa Assistance', 
                'Cruises & Special Packages', 
                'International Driver Licenses'
              ].map((item) => (
                <li key={item}>
                  <a href="#services" className="text-slate-400 hover:text-accent transition-colors text-sm">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Col */}
          <div id="contact">
            <h3 className="text-lg font-bold mb-6 text-white">Contact Us</h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="text-accent mt-1">
                  <MapPin size={20} />
                </div>
                <div className="text-sm text-slate-400">
                  <p className="text-white font-medium mb-1">Office Address</p>
                  <p>{BUSINESS_DATA.address}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="text-accent mt-1">
                  <Phone size={20} />
                </div>
                <div className="text-sm text-slate-400">
                  <p className="text-white font-medium mb-1">Phone Number</p>
                  <p>{BUSINESS_DATA.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="text-accent mt-1">
                  <Mail size={20} />
                </div>
                <div className="text-sm text-slate-400">
                  <p className="text-white font-medium mb-1">Email Address</p>
                  <p>{BUSINESS_DATA.email}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="h-px bg-white/5 mb-10" />

        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-slate-500 text-xs text-center md:text-left">
            © {currentYear} Discovery Travels. All rights reserved. Registered in Qatar.
          </p>
          <div className="flex items-center gap-6">
            <img src="https://img.icons8.com/color/48/visa.png" alt="Visa" className="h-6 opacity-30 grayscale hover:grayscale-0 transition-all" />
            <img src="https://img.icons8.com/color/48/mastercard.png" alt="Mastercard" className="h-6 opacity-30 grayscale hover:grayscale-0 transition-all" />
            <img src="https://img.icons8.com/color/48/amex.png" alt="Amex" className="h-6 opacity-30 grayscale hover:grayscale-0 transition-all" />
          </div>
        </div>
      </div>
    </footer>
  );
}
